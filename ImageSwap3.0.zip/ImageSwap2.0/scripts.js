"use strict";

/*
   Image Swapping with Arrays
   Author: Michael Kroth
   Date:   9/9/19
   Filename: scripts.js
*/
var highCards, lowCards, count, card;
var setOne = true;
highCards = ["images/jack.jpg", "images/queen.png", "images/king.png", "images/ace.jpg"];
lowCards = ["images/two.png", "images/three.png", "images/four.png", "images/five.png"];

displayThumbnail(highCards); // starting images 

// This function will loop through the array of images and display it in the thumbnail
function displayThumbnail(cards) {
    count = 0;
    document.getElementById('thumbnail').innerHTML = "";
    for (card of cards) {
        var img = document.createElement("img");
        img.src = card;
        img.onclick = function() { document.getElementById('largePic').src = this.src; };
        img.id = "thumb" + count;
        document.getElementById('thumbnail').appendChild(img);
        count += 1;
    }
}

// This function will swap the images with four new images when the larger image is double clicked
document.getElementById('largePic').addEventListener('dblclick', function() {
    if (setOne) {
        document.getElementById('largePic').src = "images/two.png"
        displayThumbnail(lowCards);
        setOne = false;
    } else {
        document.getElementById('largePic').src = "images/jack.jpg"
        displayThumbnail(highCards);
        setOne = true;
    }

});